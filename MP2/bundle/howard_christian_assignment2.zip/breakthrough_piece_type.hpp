//
// Created by Christian J Howard on 10/21/17.
//

#ifndef SRC_BREAKTHROUGH_PIECE_TYPE_HPP
#define SRC_BREAKTHROUGH_PIECE_TYPE_HPP

namespace bt {
    enum piece_t {Team1=0, Team2, None};
}

#endif //SRC_BREAKTHROUGH_PIECE_TYPE_HPP
